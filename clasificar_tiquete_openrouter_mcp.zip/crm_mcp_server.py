import os
from typing import Any

import psycopg
from dotenv import load_dotenv
from fastmcp import FastMCP
from psycopg.rows import dict_row


load_dotenv()

DATABASE_URL = os.environ["DATABASE_URL"]
MCP_HOST = os.getenv("MCP_HOST", "127.0.0.1")
MCP_PORT = int(os.getenv("MCP_PORT", "8000"))


mcp = FastMCP(
    name="CRM PostgreSQL",
    instructions=(
        "Servidor MCP de solo lectura para consultar los servicios "
        "utilizados en la clasificación de tiquetes."
    ),
)


def get_connection() -> psycopg.Connection:
    """
    Crea una conexión nueva a PostgreSQL.
    """

    return psycopg.connect(
        DATABASE_URL,
        row_factory=dict_row,
        connect_timeout=10,
    )


@mcp.tool
def listar_servicios() -> list[dict[str, Any]]:
    """
    Obtiene los servicios activos que pueden asignarse a un tiquete.
    """

    query = """
        SELECT
            id,
            nombre,
            COALESCE(descripcion, '') AS descripcion
        FROM public.servicio
        WHERE activo = TRUE
        ORDER BY nombre
    """

    with get_connection() as conn:
        with conn.cursor() as cursor:
            cursor.execute(query)
            return list(cursor.fetchall())


@mcp.tool
def obtener_servicio_por_id(servicio_id: int) -> dict[str, Any] | None:
    """
    Busca un servicio activo por su identificador.
    """

    query = """
        SELECT
            id,
            nombre,
            COALESCE(descripcion, '') AS descripcion
        FROM public.servicio
        WHERE id = %s
          AND activo = TRUE
    """

    with get_connection() as conn:
        with conn.cursor() as cursor:
            cursor.execute(query, (servicio_id,))
            return cursor.fetchone()


@mcp.tool
def buscar_servicios(texto: str) -> list[dict[str, Any]]:
    """
    Busca servicios por nombre o descripción.
    """

    texto = texto.strip()

    if not texto:
        return []

    patron = f"%{texto}%"

    query = """
        SELECT
            id,
            nombre,
            COALESCE(descripcion, '') AS descripcion
        FROM public.servicio
        WHERE activo = TRUE
          AND (
              nombre ILIKE %s
              OR descripcion ILIKE %s
          )
        ORDER BY nombre
        LIMIT 20
    """

    with get_connection() as conn:
        with conn.cursor() as cursor:
            cursor.execute(query, (patron, patron))
            return list(cursor.fetchall())


if __name__ == "__main__":
    mcp.run(
        transport="http",
        host=MCP_HOST,
        port=MCP_PORT,
    )