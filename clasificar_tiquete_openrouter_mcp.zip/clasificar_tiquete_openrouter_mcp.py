import argparse
import asyncio
import json
import os
from typing import Any

import httpx
from dotenv import load_dotenv
from fastmcp import Client
from pydantic import BaseModel, Field, ValidationError


load_dotenv()

MCP_SERVER_URL = os.getenv("MCP_SERVER_URL", "http://127.0.0.1:8000/mcp")
OPENROUTER_API_KEY = os.environ["OPENROUTER_API_KEY"]
OPENROUTER_BASE_URL = os.getenv("OPENROUTER_BASE_URL", "https://openrouter.ai/api/v1")
OPENROUTER_MODEL = os.getenv("OPENROUTER_MODEL", "openrouter/free")


class Clasificacion(BaseModel):
    servicio_id: int
    servicio: str
    confianza: float = Field(ge=0.0, le=1.0)
    justificacion: str


def normalizar_resultado_mcp(resultado: Any) -> list[dict[str, Any]]:
    """
    Extrae datos estructurados devueltos por FastMCP.
    """

    if hasattr(resultado, "data") and resultado.data is not None:
        datos = resultado.data
    elif hasattr(resultado, "structured_content"):
        datos = resultado.structured_content
    else:
        raise RuntimeError("El resultado MCP no contiene datos estructurados reconocibles.")

    if isinstance(datos, list):
        return datos

    if isinstance(datos, dict):
        for clave in ("result", "servicios", "data"):
            if isinstance(datos.get(clave), list):
                return datos[clave]

    raise RuntimeError(f"Formato inesperado al leer servicios: {type(datos).__name__}")


async def consultar_servicios_mcp() -> list[dict[str, Any]]:
    """
    Consulta el catálogo de servicios mediante MCP HTTP.
    """

    async with Client(MCP_SERVER_URL) as client:
        resultado = await client.call_tool("listar_servicios", {})
        servicios = normalizar_resultado_mcp(resultado)

    if not servicios:
        raise RuntimeError("PostgreSQL no devolvió servicios activos.")

    return servicios


def construir_prompt(texto_tiquete: str, servicios: list[dict[str, Any]]) -> str:
    catalogo = "\n".join(
        (
            f"- ID {servicio['id']}: {servicio['nombre']}. "
            f"{servicio.get('descripcion', '')}"
        )
        for servicio in servicios
    )

    return f"""
Clasifica el tiquete en exactamente uno de los servicios permitidos.

SERVICIOS PERMITIDOS:
{catalogo}

REGLAS:
1. Debes escoger únicamente un servicio de la lista.
2. servicio_id y servicio deben corresponder al mismo registro.
3. No inventes identificadores ni nombres.
4. confianza debe estar entre 0 y 1.
5. La justificación debe ser breve y basarse en el texto del tiquete.
6. No incluyas texto fuera del objeto JSON.

TIQUETE:
{texto_tiquete}
""".strip()


async def clasificar_con_openrouter(
    texto_tiquete: str,
    servicios: list[dict[str, Any]],
) -> Clasificacion:
    """
    Envía el tiquete a OpenRouter y solicita salida JSON.
    """

    prompt = construir_prompt(texto_tiquete, servicios)

    schema = Clasificacion.model_json_schema()

    payload = {
        "model": OPENROUTER_MODEL,
        "messages": [
            {
                "role": "system",
                "content": (
                    "Eres un clasificador determinista de tiquetes "
                    "institucionales de tecnología. Responde solo JSON válido."
                ),
            },
            {
                "role": "user",
                "content": prompt,
            },
        ],
        "temperature": 0,
        "response_format": {
            "type": "json_schema",
            "json_schema": {
                "name": "clasificacion_tiquete",
                "strict": True,
                "schema": schema,
            },
        },
    }

    headers = {
        "Authorization": f"Bearer {OPENROUTER_API_KEY}",
        "Content-Type": "application/json",
        # Opcionales, pero recomendados por OpenRouter para identificación de la app.
        "HTTP-Referer": "http://localhost",
        "X-OpenRouter-Title": "Laboratorio clasificador de tiquetes",
    }

    timeout = httpx.Timeout(
        connect=10.0,
        read=180.0,
        write=30.0,
        pool=10.0,
    )

    async with httpx.AsyncClient(timeout=timeout) as client:
        response = await client.post(
            f"{OPENROUTER_BASE_URL}/chat/completions",
            headers=headers,
            json=payload,
        )
        response.raise_for_status()
        datos = response.json()

    contenido = datos["choices"][0]["message"]["content"]

    try:
        return Clasificacion.model_validate_json(contenido)
    except ValidationError as error:
        raise RuntimeError(f"OpenRouter devolvió JSON inválido: {contenido}") from error


def validar_clasificacion(
    clasificacion: Clasificacion,
    servicios: list[dict[str, Any]],
) -> Clasificacion:
    """
    Verifica que el servicio devuelto exista en PostgreSQL.
    """

    servicios_por_id = {int(servicio["id"]): servicio for servicio in servicios}
    servicio_bd = servicios_por_id.get(clasificacion.servicio_id)

    if servicio_bd is None:
        raise RuntimeError(f"El modelo devolvió un ID inexistente: {clasificacion.servicio_id}")

    nombre_bd = str(servicio_bd["nombre"])

    if clasificacion.servicio.strip().casefold() != nombre_bd.casefold():
        raise RuntimeError(
            "El nombre del servicio no corresponde al ID devuelto: "
            f"ID={clasificacion.servicio_id}, "
            f"modelo={clasificacion.servicio!r}, "
            f"base_de_datos={nombre_bd!r}"
        )

    clasificacion.servicio = nombre_bd
    return clasificacion


async def ejecutar(texto_tiquete: str) -> Clasificacion:
    servicios = await consultar_servicios_mcp()
    clasificacion = await clasificar_con_openrouter(texto_tiquete, servicios)
    return validar_clasificacion(clasificacion, servicios)


def main() -> None:
    parser = argparse.ArgumentParser(
        description="Clasifica un tiquete usando OpenRouter, MCP y PostgreSQL."
    )
    parser.add_argument("tiquete", help="Texto descriptivo del tiquete")
    args = parser.parse_args()

    try:
        resultado = asyncio.run(ejecutar(args.tiquete))
        print(json.dumps(resultado.model_dump(), ensure_ascii=False, indent=2))
    except httpx.HTTPStatusError as error:
        raise SystemExit(
            f"OpenRouter respondió con error HTTP {error.response.status_code}: "
            f"{error.response.text}"
        ) from error
    except httpx.ConnectError as error:
        raise SystemExit("No fue posible conectarse con OpenRouter.") from error
    except Exception as error:
        raise SystemExit(f"Error: {error}") from error


if __name__ == "__main__":
    main()