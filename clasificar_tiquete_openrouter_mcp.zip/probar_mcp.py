import asyncio
import os

from dotenv import load_dotenv
from fastmcp import Client


load_dotenv()

MCP_SERVER_URL = os.getenv("MCP_SERVER_URL", "http://127.0.0.1:8000/mcp")


async def main() -> None:
    async with Client(MCP_SERVER_URL) as client:
        await client.ping()

        herramientas = await client.list_tools()
        print("Conexión MCP correcta")
        print("Herramientas disponibles:")

        for herramienta in herramientas:
            print(f"- {herramienta.name}")

        resultado = await client.call_tool("listar_servicios", {})
        print("\nServicios devueltos por PostgreSQL:")
        print(resultado)


if __name__ == "__main__":
    asyncio.run(main())